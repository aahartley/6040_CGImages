This is a list of all the contributors to OpenImageIO, sorted alphabetically
by first name.

If you know of somebody that I missed or have corrections, please email:
lg@openimageio.org

* Adam Mains
* Akihiro Yamasaki
* Alan Jones
* Alejandro Conty
* Alex Hughes
* Alex Schworer
* Alexander Kuleshov
* Alexander Murashko
* Alexandre Gauthier
* Alexis Oblet
* Alexy Pawlow
* Alister Chowdhury
* Aman Shah
* Ananth Garre
* Anders Langlands
* Angus Davis
* Anthony Nemoff
* Aras Pranckevičius
* Arkady Shapkin
* Basileios Anastasatos
* Bastien Montagne
* Ben De Luca
* Bernhard Rosenkraenzer
* Biswapriyo Nath
* Blair Tennessy
* Blazej Floch
* Brad Smith
* Brecht Van Lommel
* Brent Davis
* Brian Hall
* Brice Gros
* Carl Rand
* Cassian Andrei
* Chad Dombrova
* Changlin Hsieh
* Chris Crosetto
* Chris Foster
* Chris Kulla
* Chris Whalen
* Christoph Willing
* Cliff Stein
* Clément Champetier
* Dalai Felinto
* Dan Wexler
* Daniel Dresser
* Daniel Flehner Heen
* Daniel Wyatt
* David Aguilar
* David Gordon
* Deepak Gopinath
* Dennis Schridde
* Dieter De Baets
* Dinko Galetik
* Dominik Bartkiewicz
* Duncan Chan
* Dustin Rodrigues
* Edgar Velazquez-Armendariz
* Eloi Du Bois
* Elvic Liang
* Fabien Castan
* Fabien Servant
* Fredrik Averpil
* Frédéric Devernay
* Gaurav Bansal
* Gerdya
* Ghislain Antony Vaillant
* Gonzalo Garramuño
* Gregor Mueckl
* Grégoire De Lillo
* Guillaume Chatelet
* Hanspeter Niederstrasser
* Harry Mallon
* Heiko Becker
* Henri Fousse
* Hugh Macdonald
* Imarz
* Irena Damsky
* Ismael Cortes
* Jan Hettenkofer
* Jan Honsbrok
* Jens Lindgren
* Jep Hill
* Jeph Alapat
* Jeremy Rose
* Jeremy Selan
* Jim Hourihan
* Joachim Reichel
* Johannes Unterguggenberger
* John Burnett
* John Fea
* John Haddon
* Jonathan Hearn
* Jonathan Scruggs
* Joris Nijs
* Joseph Goldstone
* Julien Enche
* Justin Israel
* Justina Mikonyte
* Kazuki Takahashi
* Kevin Brightwell
* Kimball Thurston
* Konrad Kleine
* Krzysztof Blicharski
* Larry Gritz (project leader)
* LazyDodo
* Leonid Onokhov
* Leszek Godlewski
* Lucas Panian
* Lucille Caillaud
* Lukas Schrangl
* Lukasz Maliszewski
* Luke Emrose
* M Joonas Pihlaja
* Malcolm Humphreys
* Manuel Gamito
* Manuel Leonhardt
* Marcos Fajardo
* Marie Fetiveau
* Mariusz Szczepanczyk
* Mark Boorer
* Mark Visser
* Massimo Paladin
* Matteo F. Vescovi
* Matthew E. Levine
* Max Liani
* Merwan Achibet
* Michael Cho
* Michael Oliver
* Michel Lerenard
* Michel Normand
* Mikael Sundell
* Mike Root
* Morteza Ramezanali
* Nandan Dubey
* Nathan Rusch
* Nicholas Yue
* Nick Black
* Nicolas Burtnyk
* Nixon Kwok
* Noah Rahm (designer of our logo!)
* Northon Patrick
* Nuno Cardoso
* Ole Gulbrandsen
* Ott Tinn
* Pascal Lecocq
* Patrick Hodoul
* Patrick Piché
* Paul Melis
* Paul Molodowitch
* Pavel Karneliuk
* Pete Larabell
* Philip Nemec
* Pino Toscano
* Povilas Kanapickas
* Puneet Jain
* Radu Arjocu
* Ramon Montoya
* Ray Molenkamp
* Rémi Achard
* Richard Shaw
* Robert Matusewicz
* Roeland Schoukens
* Roman Zulak
* Rui Li
* Russell Greene
* Ryen
* Saket Jalan
* Sam Richards
* Samuel Nicholas
* Scott Wilson
* Sebastian Elsner
* SebTV
* Seifeddine Dridi
* Sergey Sharybin
* Shane Ambler
* Simon Boorer
* Solomon Boulos
* SRHMorris
* Stefan Bruens
* Stefan Stavrev
* Thiago Ize
* Thomas Dinges
* Thomas Mansencal
* Till Dechent
* Tim D. Smith
* Tim Grant
* Tom Knowles
* Troy James Sobotka
* Vinod Khare
* Vishal Agrawal
* Vitor Franchi
* Wayne Arnold
* Will Rosecrans
* William Krick
* Wormszer
* Xo Wang
* Yang Yang
* Yann Lanthony
* zomgrolf
