# Code of Conduct

The OpenImageIO project abides by Linux Foundation's code of conduct, which
you can read in full [here](https://lfprojects.org/policies/code-of-conduct).

To report incidents or to appeal reports of incidents, send email to
the Manager of LF Projects at manager@lfprojects.org.
