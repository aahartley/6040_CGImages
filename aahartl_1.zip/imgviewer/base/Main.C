#include "ImgViewer.h"


int main( int argc, char** argv )
{
    ImgViewer viewer;
    viewer.run(argc, argv);
    

}