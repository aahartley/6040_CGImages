This is a list of contributors to the OpenEXR project, sorted
alphabetically by first name.

If you know of missing, please email: info@openexr.com.

* Andre Mazzone
* Andrew Kunz
* Arkady Shapkin
* Arkell Rasiah
* Brendan Bolles
* Cary Phillips
* Christina Tempelaar-Lietz
* Christopher Horvath
* Christopher Kulla
* Daniel Kaneider
* Drew Hess
* Ed Hanway
* Edward Kmett
* Eric Sommerlade
* Eric Wimmer
* E Sommerlade
* Florian Kainz
* Halfdan Ingvarsson
* Ibraheem Alhashim
* Jack Kingsman
* Jamie Kenyon
* Ji Hun Yu
* John Loy
* John Mertic
* Jonathan Stone
* Juri Abramov
* Karl Rasche
* Kevin Wheatley
* Kimball Thurston
* Larry Gritz
* Liam Fernandez
* Lucy Wilkes
* Michael Thomas
* Nicholas Yue
* Nick Porcino
* Nick Rasmussen
* Nicolas Chauvet
* Paul Schneider
* Peter Hillman
* Piotr Stanczyk
* Ralph Potter
* Richard Goedeken
* Shawn Walker-Salas
* Simon Otter
* Srinath Ravichandran
* Thanh Ha
* Thorsten Kaufmann
* Wenzel Jakob
* Wojciech Jarosz
* Xo Wang
* Yujie Shu
